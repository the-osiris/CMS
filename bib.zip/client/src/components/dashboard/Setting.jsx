import React from "react";

function Setting() {
  return <div>Setting</div>;
}

export default Setting;
